# Production credits

The music is an excerpt of “Базовый минимум” from the SABI audio file supplied for this edit. The camera moves, illustrations and tactile sound effects were created for Signal Path. The two audio stems can be remixed independently.

The composition follows the native timeline pattern of OpenMotion’s [Decision Tree template](https://github.com/nexu-io/openmotion/tree/a44c714d0e702f3b9b02be8a7512bbf278c6294b/template-library/decision-tree). Its OpenMotion Canvas helper draws the moving print on the ticket.

GSAP 3.14.2 and the Canvas helper carry the notices under `vendor/`. The notices for Inter, Instrument Serif and DejaVu Sans Mono are next to the fonts in `assets/`.
