'use strict';
const inlet=-318, outlet=318;
const ticketCut=new Path2D('M -207 -99 H 207 Q 219 -99 219 -87 V -17 C 191 -17 191 17 219 17 V 87 Q 219 99 207 99 H -207 Q -219 99 -219 87 V 17 C -191 17 -191 -17 -219 -17 V -87 Q -219 -99 -207 -99 Z');
function ticketStation(b,P,time) {
  line(inlet,0,outlet,0,P.line,3);
  const slide=spring(Math.max(0,b),6.5);
  move(-8-176*(1-slide),14*(1-slide),()=>{
    move(4,8,()=>fillPath(ticketCut,ink));
    fillPath(ticketCut,paper,ink,2.6);
    withStyle(()=>{
      g.clip(ticketCut);rect(-219,-99,96,198,0,mint);
      openMotionStrip.draw(g,time,.58);
      dashed(()=>line(-122,-104,-122,103,ink,1.5),[5,5]);
      rect(-188,-14,40,28,14,ink);arrow(-168,0,7.5,mint);
    });
    mono('INCOMING TICKET',-97,-65,12,ink);
    type('SUP-4821',-99,0,49,ink,'left',-3);
    textRun('VPN dropouts',-96,41,28,'s',ink);
    line(-96,55,187,55,'#bcb6a2',1);
    const widths=[2,4,1,2,1,5,3,1,4,2,2,1,3,4,1,2,2,4,1,1,5];
    let x=-95;for(const width of widths){rect(x,68,width,14,0,ink);x+=width+2;}
    mono('01',187,80,14,ink,'right');
    ringPort(218,0,ink,paper,4.5);
  },-.085*(1-slide)-.021,.55+.45*slide);
  if(b<1.04){traveler(route([inlet,0],[-219,0]),ramp(b,0,.78),P.hot,true);}
}
function triggerStation(b,P) {
  line(inlet,0,outlet,0,P.line,3.5);
  const activation=spring(Math.max(0,b-.37),5.5);
  move(0,0,()=>{
    const r=115;
    dot(4,8,r+2,ink);
    dot(0,0,r,paper,ink,3);dot(0,0,r-11,deep,ink,2);
    for(let i=0;i<64;i++) {
      const a=i/64*tau, outer=r-17,inner=outer-(i%4===0?11:5);
      line(Math.cos(a)*inner,Math.sin(a)*inner,Math.cos(a)*outer,Math.sin(a)*outer,i%4===0?paper:'#8c9e83',i%4===0?2.2:1.1);
    }
    arc(0,0,76,Math.PI*.80,Math.PI*2.22,mint,6);
    arc(0,0,76,Math.PI*.45,Math.PI*.70,orange,6);
    dot(0,0,58,'#203f34',paper,1.2);
    move(0,0,()=>{
      svg('M -19 -6 L 62 -2 L 73 0 L 61 3 L -19 9 Z',orange,ink,1.4);
    },mix(2.55,5.98,activation));
    dot(0,0,14,paper,ink,2);dot(0,0,5,ink);
    mono('RELAIS',0,49,10,paper,'center',1.1);
  });
  const jack=(x,label,on)=>{
    rect(x-68,-26,136,52,26,on?mint:P.bg,on?ink:P.line,2);
    dot(x-47,0,5,on?ink:P.line);mono(label,x+7,5,14,on?ink:P.fg,'center',.35);
  };
  jack(-216,'JIRA',true);jack(216,'WORKFLOW',activation>.85);
  if(b>.72)traveler(route([115,0],[148,0]),ramp(b,.74,1.35),P.hot,true);
  fade(ramp(b,.42,.87),()=>{for(let i=0;i<3;i++){const a=-1.15+i*.23;line(130*Math.cos(a),130*Math.sin(a),(141+8*Math.sin(Math.PI*between(b,.55,1.45)))*Math.cos(a),(141+8*Math.sin(Math.PI*between(b,.55,1.45)))*Math.sin(a),P.hot,2.5);}});
}
const splitRoutes=[-81,0,81].map(y=>pathInfo(joinPaths(cubic([-177,0],[-74,0],[-108,y],[-5,y]),[[ -5,y],[86,y]])));
const returnRoutes=[-81,0,81].map(y=>pathInfo(cubic([208,y],[272,y],[232,0],[301,0])));
function triageStation(b,P) {
  const bright=P.hot;
  line(inlet,0,-177,0,P.line,3);line(301,0,outlet,0,P.line,3);
  for(let i=0;i<3;i++){
    rail(splitRoutes[i],P.line,2.5);rail(returnRoutes[i],P.line,2.5);
    const y=(i-1)*81, chosen=i===1, a=chosen?ramp(b,1.0,1.5):0;
    rect(82,y-25,126,50,25,chosen&&a>.3?ink:P.bg,P.line,2);
    mono(['N1','N2','N3+'][i],123,y+7,20,chosen&&a>.3?paper:P.fg,'center');
    if(chosen){dot(183,y,8,a>.3?mint:P.line);if(a>.3) check(183,y,7,ink,1.7);}
    else{line(179,y,187,y,P.line,1.4);}
  }
  const p=ramp(b,.28,1.44);rail(splitRoutes[1],ink,4,0,p);
  if(p>0&&p<1)traveler(splitRoutes[1],p,bright);
  if(b>1.6){const m=ramp(b,1.62,2.64);rail(returnRoutes[1],ink,4,0,m);if(m<1)traveler(returnRoutes[1],m,bright,true);}
  move(-182,0,()=>{
    rect(-65,-66,130,138,20,ink);rect(-68,-70,130,134,20,paper,ink,2);
    rect(-49,-50,35,22,6,ink);
    line(-40,-39,-23,-39,mint,2);line(-34,-44,-34,-34,mint,2);
    const v=ramp(b,.25,.99);
    for(let i=0;i<3;i++){const y=-7+i*17;line(-47,y,mix([-6,25,1][i],[37,12,23][i],v),y,ink,i===0?4.5:2.4);}
    mono('SIGNAL',-47,52,10,ink);
  },-.035*(1-ramp(b,.1,1)));
  fade(ramp(b,1.5,2.15),()=>mono('NETWORK',-3,-15,13,ink,'center',1.1));
}
function documentStation(b,P) {
  line(inlet,0,outlet,0,P.line,3);
  const attachedWire=route([151,54],[280,0]);
  rail(attachedWire,P.line,1.8);
  const attach=spring(Math.max(0,b-.58),5.3);
  const packet=route([-262,-109],[-121,-46]);
  dashed(()=>rail(packet,P.line,2),[3,7]);
  move(-272,-113,()=>{dot(0,0,17,P.bg,P.fg,1.6);plus(0,0,P.fg,6);});
  if(b>.08&&b<1.44)traveler(packet,ramp(b,.08,1.4),P.hot,true);
  move(-26,4,()=>{
    move(-22-26*(1-attach),-10,()=>{
      rect(-133,-82,260,174,8,'#89a98c',ink,2.2);
      for(let i=0;i<6;i++)line(-107,-52+i*21,94,-52+i*21,deep,1);
    },-.15);
    move(4-20*(1-attach),-12,()=>rect(-124,-82,253,166,7,warm,ink,2.2),-.054);
    move(20+42*(1-attach),5-28*(1-attach),()=>{
      const sheet=new Path2D('M -137 -82 Q -137 -90 -129 -90 H 96 L 136 -50 V 84 Q 136 90 129 90 H -129 Q -137 90 -137 82 Z');
      move(3,6,()=>fillPath(sheet,ink));fillPath(sheet,paper,ink,2.3);
      svg('M 96 -90 V -52 Q 96 -49 99 -49 H 136 Z',mint,ink,1.7);
      mono('APPROVED GUIDE',-114,-61,12,ink,'left',1);
      type('KB-104',-116,-8,47,ink,'left',-2.7);
      italic('VPN checks',-114,28,32,ink);
      for(let i=0;i<3;i++)line(-113,48+i*9,[-10,47,19][i],48+i*9,'#7b8a78',1.6);
    },.027+.04*(1-attach));
  });
  const seal=ramp(b,1.1,1.79);
  move(134+36*(1-seal),55-42*(1-seal),()=>{
    const r=38;dot(3,4,r,ink);dot(0,0,r,mint,ink,2.3);
    dashed(()=>arc(0,0,29,0,tau,ink,1.2),[2,4]);
    if(seal>.12)check(0,0,29*seal,ink,4);
  },-.1);
  if(b>1.65){const v=ramp(b,1.65,2.76);rail(attachedWire,P.hot,2.8,0,v);if(v<1)traveler(attachedWire,v,P.hot,true);}
  fade(ramp(b,1.22,1.8),()=>mono('SOURCE LINKED',183,89,12,P.fg,'left',.25));
}
const criticForward=pathInfo([[-104,-15],[82,-15]]);
const revisionRoute=pathInfo(joinPaths(cubic([164,41],[164,74],[164,97],[99,97]),[[99,97],[-93,97]],cubic([-93,97],[-159,97],[-166,83],[-166,41])));
function planStation(b,P) {
  line(inlet,0,-242,0,P.line,3);line(244,0,outlet,0,P.line,3);
  rail(criticForward,P.line,3);rail(revisionRoute,P.line,2.4);
  const first=ramp(b,.06,.89), back=ramp(b,1.0,2.0), recheck=ramp(b,2.04,2.91);
  if(first>0){rail(criticForward,ink,3,0,first);if(first<1)traveler(criticForward,first,paper,true);}
  if(back>0){rail(revisionRoute,ink,3,0,back);if(back<1)traveler(revisionRoute,back,paper);}
  if(recheck>0&&recheck<1)traveler(criticForward,recheck,mint);
  move(-166,-16,()=>{
    dot(3,5,70,ink);dot(0,0,70,paper,ink,2.4);dot(0,0,56,null,'#a7a995',1.1);
    const a=-.20+.34*back-.11*recheck;
    move(0,-2,()=>{
      svg('M -28 30 L -3 -29 L 2 -27 L -20 31 Z',deep);
      svg('M 1 -28 L 28 30 L 22 31 L -3 -24 Z',deep);
      line(-18,10,17,7,ink,2);dot(0,-24,8,mint,ink,2);dot(0,-24,2.5,ink);
    },a);
    mono('ARCHITECT',0,-87,14,ink,'center',.5);
  });
  const passed=b>=2.86;
  move(164,-16,()=>{
    const diamond=new Path2D('M -71 -8 L -9 -67 Q 0 -75 9 -67 L 73 -8 Q 80 0 73 8 L 9 67 Q 0 75 -9 67 L -71 8 Q -79 0 -71 -8 Z');
    move(3,6,()=>fillPath(diamond,ink));fillPath(diamond,passed?mint:ink,ink,2.2);
    const f=passed?ink:paper;
    type(b<.83?'···':passed?'9.2':'8.6',0,4,33,f,'center',-2);
    mono('/ 10',0,22,12,f,'center',0);
    mono('CRITIC',0,-87,14,ink,'center',.6);
  });
  arrow(-5,97,6,ink,-1);
  mono('REVISION',0,123,13,ink,'center',1);
  if(passed) {line(240,0,302,0,ink,3);move(271,-17,()=>check(0,0,13,ink,2.6));}
}
const specialistY=[-85,0,85];
const splitReview=specialistY.map(y=>pathInfo(cubic([-185,0],[-111,0],[-154,y],[-66,y])));
const mergeReview=specialistY.map(y=>pathInfo(cubic([97,y],[165,y],[133,0],[210,0])));
function verifyStation(b,P) {
  line(inlet,0,-241,0,P.line,3);line(210,0,outlet,0,P.line,3);
  for(let i=0;i<3;i++) {
    const y=specialistY[i],v=ramp(b,.22+i*.20,1.1+i*.20),m=ramp(b,1.48+i*.19,2.44+i*.19);
    rail(splitReview[i],P.line,2.3);rail(mergeReview[i],P.line,2.3);
    if(v>0){rail(splitReview[i],P.hot,2.7,0,v);if(v<1)traveler(splitReview[i],v,P.hot,true);}
    if(m>0){rail(mergeReview[i],P.hot,2.7,0,m);if(m<1)traveler(mergeReview[i],m,P.hot,true);}
    const on=b>1.05+i*.19;
    rect(-66,y-25,163,50,7,on?paper:P.bg,on?ink:P.line,2);
    textRun(['Accuracy','Security','Clarity'][i],-50,y+7,20,'r',on?ink:P.fg);
    if(on){dot(75,y,10,deep);check(75,y,9,mint,1.9);}
    else dot(75,y,5,null,P.line,1.7);
  }
  move(-238,0,()=>{
    const r=53;dot(3,5,r,ink);dot(0,0,r,mint,ink,2.4);
    for(let i=0;i<32;i++){const a=i/32*tau;line(44*Math.cos(a),44*Math.sin(a),(i%4?47:49)*Math.cos(a),(i%4?47:49)*Math.sin(a),deep,1.2);}
    svg('M -28 0 Q 0 -34 28 0 Q 0 34 -28 0 Z',null,ink,3);
    dot(0,0,10,ink);dot(3,-3,3.1,paper);
  });
  mono('INDEPENDENT',-238,85,13,P.fg,'center',.25);
  mono('VERIFIER',-238,105,13,P.fg,'center',.25);
  const final=ramp(b,2.0,2.87);
  move(244,0,()=>{
    dot(3,4,40,ink);dot(0,0,40,final>.8?P.hot:P.bg,final>.8?ink:P.line,2);
    if(final>.8){type('9.3',0,4,23,ink,'center',-1.2);mono('/ 10',0,20,9,ink,'center',0);}
    else {for(let i=0;i<3;i++)dot((i-1)*10,0,2.4,P.fg);}
  });
}
function cursor(x,y,scale=1) {
  move(x,y,()=>{
    const arrowShape=new Path2D('M 0 0 L 8 35 L 16 25 L 24 39 L 31 35 L 23 22 L 36 21 Z');
    move(2,3,()=>fillPath(arrowShape,ink));fillPath(arrowShape,paper,ink,2.1);
  },-.12,scale);
}
const approvalLink=pathInfo([[-41,0],[44,0]]);
function publishStation(b,P) {
  line(inlet,0,-268,0,P.line,3);line(267,0,outlet,0,P.line,3);
  rail(approvalLink,P.line,3);
  if(b>.88){let v=ramp(b,1,1.63);rail(approvalLink,ink,3.5,0,v);if(v<1)traveler(approvalLink,v,orange,true);}
  const first=b>=.88,second=b>=2.22;
  function key(x,label,hit,on,primary){
    const down=Math.sin(Math.PI*between(b,hit-.12,hit+.19))*6;
    move(x,down,()=>{
      rect(-114,-41+6-down,228,87,18,ink);
      rect(-114,-43,228,86,18,primary?(on?mint:ink):(on?mint:paper),ink,2.6);
      const col=primary&&!on?paper:ink;
      if(on){dot(-72,0,15,ink);check(-72,0,16,mint,2.7);}
      else if(primary){dot(-72,-4,5.5,null,col,2);svg('M -85 9 Q -72 -7 -59 9',null,col,2);}
      else {svg('M -84 -4 L -61 -13 L -72 12 L -74 1 Z',null,col,2.35);}
      type(label,-41,9,29,col,'left',-1.3);
    });
  }
  mono('HUMAN APPROVAL',-154,-68,13,ink,'center',.45);
  mono('JIRA PUBLISH',158,-68,13,ink,'center',.45);
  key(-155,first?'Approved':'Approve',.88,first,true);
  key(158,second?'Published':'Publish',2.22,second,false);
  const approach=glide(between(b,0,.78)),next=glide(between(b,1.16,2.12)),leave=ramp(b,2.55,3.42);
  let x=mix(-186,-104,approach),y=mix(89,15,approach);
  x=mix(x,186,next);y=mix(y,13,next)-34*Math.sin(next*Math.PI);x+=18*leave;y+=62*leave;
  fade(1-leave,()=>cursor(x,y,1-.12*(Math.sin(Math.PI*between(b,.76,1.04))+Math.sin(Math.PI*between(b,2.09,2.4)))));
}
const drawStation=[ticketStation,triggerStation,triageStation,documentStation,planStation,verifyStation,publishStation];
