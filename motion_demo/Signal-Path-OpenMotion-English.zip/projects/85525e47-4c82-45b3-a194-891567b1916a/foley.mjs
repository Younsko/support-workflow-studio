// Original tactile sound design. The camera and this renderer share edit-grid.js.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import './edit-grid.js';

const root=path.dirname(fileURLToPath(import.meta.url));
const {fps,duration,marks}=globalThis.SignalEdit;
const sr=48000, tau=2*Math.PI, total=sr*duration;
const tracks=[new Float64Array(total),new Float64Array(total)];
let seed=0x4271c;
function noise(){seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/2147483648-1;}
function band(hz,q){
  const w=tau*hz/sr, k=Math.sin(w)/(2*q);
  const b=k/(1+k), a1=-2*Math.cos(w)/(1+k), a2=(1-k)/(1+k);
  let x1=0,x2=0,y1=0,y2=0;
  return x=>{const y=b*(x-x2)-a1*y1-a2*y2;x2=x1;x1=x;y2=y1;y1=y;return y;};
}
function movingBand(){
  let low=0,mem=0;
  return (x,hz)=>{const f=2*Math.sin(Math.PI*hz/sr);low+=f*mem;
    mem+=f*(x-low-1.18*mem);return mem;};
}
function equalPan(value,pan){return [value*Math.cos((pan+1)*Math.PI/4),value*Math.sin((pan+1)*Math.PI/4)];}
function synth(length,make){
  const a=new Float64Array(Math.ceil(length*sr)),b=new Float64Array(a.length);
  for(let i=0;i<a.length;i++){const x=make(i/sr,i);a[i]=x[0];b[i]=x[1];}
  return [a,b];
}
function rub(duration,pan,variation,travel=false){
  const brush=movingBand(),air=band(travel?5300:3650,.88),fiber=band(1500+variation*140,1.25);
  return synth(duration,t=>{
    const u=t/duration, win=Math.sin(Math.PI*u)**(travel?1.75:1.25);
    const x=noise(),f=travel?490+2780*Math.sin(u*Math.PI*.80)**1.4:1700+960*Math.sin(Math.PI*u);
    const rasp=travel?.18:.40;
    const ridges=1-rasp+rasp*(.5+.5*Math.sin(tau*(53*t+17*t*t)+variation))**4;
    const shaped=(brush(x,f)*.85+air(x)*.16+fiber(x)*.18)*win*ridges;
    return equalPan(shaped,travel?Math.max(-.8,Math.min(.8,pan+.76*(.5-u))):pan-.12+.24*u);
  });
}
const impactTypes={
  relay:     [370,1080,2820,.17,.025,.23,.012,-.10,.085],
  selector:  [530,1420,3170,.13,.021,.25,.010,.24,.068],
  clip:      [470,1780,3450,.10,.037,.29,.018,.24,.10],
  revise:    [258,630,1210,.19,.040,.17,.025,.27,.141],
  pass:      [660,1700,2980,.20,.052,.23,.012,.27,.16],
  'review-a':[740,1560,2770,.08,.020,.19,.010,-.14,.065],
  'review-b':[810,1770,3050,.08,.021,.19,.010,.00,.065],
  'review-c':[920,2020,3410,.07,.023,.20,.011,.14,.070],
  verified:  [576,1410,2630,.11,.044,.19,.011,.28,.12],
  approve:   [360,932,2250,.28,.035,.33,.017,-.22,.155],
  publish:   [550,1685,3380,.18,.052,.44,.014,.26,.21]
};
function impact(name){
  const [lo,mid,hi,body,ring,grain,release,pan,length]=impactTypes[name];
  const top=band(hi,1.12),edge=band(mid,1.45),soft=band(710,.65);
  return synth(length,t=>{
    const w=noise(),at=1-Math.exp(-t/.00045),lat=Math.max(0,t-release);
    const hit=Math.exp(-t/.0042)+.24*(t>=release)*Math.exp(-lat/.003);
    const transient=at*hit*(grain*(top(w)+.6*edge(w))+.07*soft(w));
    const r=at*(body*Math.sin(tau*lo*t+.40*(1-Math.exp(-t/.006)))*Math.exp(-t/(ring*.62))
      +.11*Math.sin(tau*mid*t+.18)*Math.exp(-t/(ring*.42))
      +.045*Math.sin(tau*hi*t+.12)*Math.exp(-t/(ring*.26)));
    const tail=name==='publish' && t>.034 ?
      .026*(1-Math.exp(-(t-.034)/.003))*Math.exp(-(t-.034)/.039)*
      (Math.sin(tau*1712*(t-.034))+.28*Math.sin(tau*3424*(t-.034))):0;
    return equalPan(transient+r+tail,pan);
  });
}
const levels={
  'paper-in':.133,relay:.228,selector:.295,leaf:.146,clip:.207,revise:.226,backtrack:.170,
  pass:.228,'review-a':.155,'review-b':.161,'review-c':.172,verified:.178,
  approve:.335,publish:.38,return:.150,
  'travel-1':.095,'travel-2':.166,'travel-3':.17,'travel-4':.156,'travel-5':.14,'travel-6':.14
};
function effect(name){
  if(name.startsWith('travel-')){
    const index=Number(name.at(-1));return rub(.18+(index%3)*.028,0,index,true);
  }
  if(name==='return')return rub(.30,-.09,9,true);
  if(name==='backtrack'){
    const source=rub(.23,.12,2,true);
    return [source[0].reverse(),source[1].reverse()];
  }
  if(name==='leaf')return rub(.205,.11,4);
  if(name==='paper-in')return rub(.20,-.37,1);
  return impact(name);
}
// The measured energy peak of each gesture, including a swish, lands on its cue.
// Use the first 4 ms of the impact for material sounds so a release never steals the sync point.
function place(mark){
  const [a,b]=effect(mark.sound), click=Object.hasOwn(impactTypes,mark.sound);
  let best=0,bestAt=0,energy=0,pk=0;
  const envelopeWindow=click?48:288;
  const locLimit=click?Math.round(.005*sr):a.length;
  for(let i=0;i<a.length;i++){
    pk=Math.max(pk,Math.abs(a[i]),Math.abs(b[i]));
    energy+=a[i]*a[i]+b[i]*b[i];
    if(i>=envelopeWindow)energy-=a[i-envelopeWindow]**2+b[i-envelopeWindow]**2;
    if(i<locLimit&&energy>best){best=energy;bestAt=i;}
  }
  const center=Math.max(0,bestAt-Math.floor(envelopeWindow/2));
  const gain=levels[mark.sound]/(pk||1);
  if(!Number.isFinite(gain))throw new Error('Missing gain for '+mark.sound);
  const origin=Math.round(mark.frame*sr/fps)-center;
  for(let i=0;i<a.length;i++){
    const dest=origin+i;if(dest<0||dest>=total)continue;
    const tail=Math.min(1,(a.length-1-i)/Math.round(.0025*sr));
    tracks[0][dest]+=a[i]*gain*tail;tracks[1][dest]+=b[i]*gain*tail;
  }
}
for(const mark of marks)if(mark.sound)place(mark);
const wav=Buffer.alloc(44+total*4);
wav.write('RIFF',0);wav.writeUInt32LE(36+total*4,4);wav.write('WAVEfmt ',8);wav.writeUInt32LE(16,16);
wav.writeUInt16LE(1,20);wav.writeUInt16LE(2,22);wav.writeUInt32LE(sr,24);wav.writeUInt32LE(sr*4,28);
wav.writeUInt16LE(4,32);wav.writeUInt16LE(16,34);wav.write('data',36);wav.writeUInt32LE(total*4,40);
for(let i=0;i<total;i++)for(let ch=0;ch<2;ch++){
  if(Math.abs(tracks[ch][i])>=1)throw new Error('Clipping in the effects stem');
  wav.writeInt16LE(Math.round(32767*tracks[ch][i]),44+(2*i+ch)*2);
}
fs.writeFileSync(path.join(root,'assets','workflow-sfx.wav'),wav);
console.log(marks.filter(m=>m.sound).length+' picture-locked stereo sound cues.');
