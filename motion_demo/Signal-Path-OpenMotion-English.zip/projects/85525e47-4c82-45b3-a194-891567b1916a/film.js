'use strict';
// OpenMotion Decision Tree staging. The horizontal camera and all decisions use the same beat clock.
const BARS=7, SECONDS=14, DX=825;
const railHeights=[12,-55,45,-22,32,-47,5];
const palette=[
  {bg:'#17372e',fg:'#f4eedc',hot:'#d4ee92',line:'#75917d',dim:'#b4c4a9'},
  {bg:'#17372e',fg:'#f4eedc',hot:'#edac86',line:'#75917d',dim:'#b4c4a9'},
  {bg:'#e5e6c9',fg:'#19392e',hot:'#ed9d76',line:'#8f9e83',dim:'#4c6653'},
  {bg:'#264336',fg:'#f4eedc',hot:'#deeca7',line:'#82987b',dim:'#c4cdb0'},
  {bg:'#eaa780',fg:'#1c352b',hot:'#e3f2a1',line:'#9f765a',dim:'#644c3d'},
  {bg:'#17372e',fg:'#f4eedc',hot:'#d5e99d',line:'#80907d',dim:'#b6c4ad'},
  {bg:'#f1e8d3',fg:'#1b392e',hot:'#b2ce73',line:'#919c85',dim:'#53664e'}
];
const copy=[
  ['A ticket','arrives.','“My VPN disconnects during calls.”','INTAKE'],
  ['The flow','starts.','The Jira trigger starts the run.','TRIGGER'],
  ['Sort','the request.','Normalized and routed to the N2 support lane.','NORMALIZE & TRIAGE'],
  ['Find','the right guide.','Approved guidance is attached to the request.','KNOWLEDGE'],
  ['Revise','the plan.','Below 9/10, the plan loops back for revision.','PLAN'],
  ['Verify','the draft.','Three reviews independently verify the draft.','REVIEW'],
  ['Your','call.','You approve the response, then publish it.','PUBLISH']
];
const pColor=(i,j,u)=>Object.fromEntries(Object.keys(palette[0]).map(k=>[k,color(palette[i][k],palette[j][k],u)]));
const yAt=j=>railHeights[mod(j,BARS)];
const curves=Array.from({length:BARS},(_,i)=>{
  const dy=yAt(i+1)-yAt(i);
  return pathInfo(joinPaths([[outlet,0],[outlet+14,0]],cubic([outlet+14,0],[DX*.51,0],[DX*.49,dy],[DX+inlet-15,dy]),[[DX+inlet-15,dy],[DX+inlet,dy]]));
});
function mark(x,y,c){
  g.save();g.translate(x,y);line(0,10,10,0,c,3.6);line(8,16,20,4,c,3.6);line(17,17,24,10,c,3.6);g.restore();
}
function pageHead(P){
  mark(52,39,P.fg);type('Support Workflow Studio',88,57,19,P.fg,'left',-.6);
  mono('SYNTHETIC CASE',907,55,13,P.dim,'right',1.35);
  line(52,78,908,78,P.line,1);
}
function heading(i,next,u,P){
  // Both lines turn over inside separate print baselines. They never overlap.
  function lineSlot(y,h,style,size,offset) {
    g.save();g.beginPath();g.rect(44,y-h+5,660,h+8);g.clip();
    const offsetY=glide(between(u,offset,1))*h;
    if(offsetY<h-.01)textRun(copy[i][style==='s'?1:0],52,y-offsetY,size,style,P.fg,'left',style==='s'?-2.7:-4.3);
    if(offsetY>.01)textRun(copy[next][style==='s'?1:0],52,y+h-offsetY,size,style,P.fg,'left',style==='s'?-2.7:-4.3);
    g.restore();
  }
  lineSlot(178,89,'b',88,0);lineSlot(266,94,'s',104,.075);
  // A large folio is deliberately subordinate to the action and readable at thumbnail size.
  const current=u<.52?i:next, fold=u<.52?between(u,0,.52):1-between(u,.52,1);
  move(890,208+fold*4,()=>{
    fade(1-.78*fold,()=>italic(String(current+1).padStart(2,'0'),0,0,100,P.fg,'right'));
  });
  line(796,225,903,225,P.line,1);
  mono('OF 07',900,247,12,P.dim,'right',1.5);
}
function drawField(P,camX,zoom,beat){
  // Small register marks gently move behind the track at a slower parallax rate.
  const offset=mod(camX*.27,58);
  fade(.27,()=>{g.fillStyle=P.line;
    for(let y=347;y<720;y+=54){ for(let x=15-offset;x<963;x+=58){g.fillRect(x,y,1.5,1.5);}}
  });
  for(const y of [316,739]){line(52,y,908,y,P.line,1);for(const x of [52,908])plus(x,y,P.dim,3.8);}
  for(let x=62;x<907;x+=14){const len=(Math.round((x-62)/14)%5===0?6:3);line(x,316,x,316+len,P.line,.75);}
}
const focusKeys=[
  [[0,-45],[.85,-22],[2.72,22]],
  [[0,-38],[.8,-8],[2.37,40]],
  [[0,-55],[.65,-35],[1.7,32],[2.78,55]],
  [[0,-40],[1.05,-5],[2.5,37]],
  [[0,-56],[.9,59],[2.02,-54],[2.86,65]],
  [[0,-58],[1.3,4],[2.82,57]],
  [[0,-55],[.94,-41],[2.2,54]]
];
function focusOn(id,b){
  const keys=focusKeys[id];
  let shift=keys[0][1];
  for(let k=1;k<keys.length;k++)shift+=(keys[k][1]-keys[k-1][1])*ramp(b,keys[k-1][0],keys[k][0]);
  return shift;
}
const exits=[212,284,299,280,241,286,272].map(x=>pathInfo([[x,0],[outlet,0]]));
function worldGraph(beat,i,b,P,time){
  const transfer=glide(between(b,2.98,4));
  const camera=DX*(i+transfer)+mix(focusOn(i,b),focusOn((i+1)%BARS,0),transfer);
  const zoom=1.05+.085*ramp(b,.12,1.45)*(1-ramp(b,2.42,3.74))-.13*Math.sin(transfer*Math.PI);
  const yCamera=mix(yAt(i),yAt(i+1),transfer);
  drawField(P,camera,zoom,beat);
  g.save();g.beginPath();g.rect(0,329,960,401);g.clip();
  g.translate(480,535);g.scale(zoom,zoom);g.translate(-camera,-yCamera);
  for(let j=i-1;j<=i+1;j++){
    const id=mod(j,BARS),x=DX*j,y=yAt(j),path=curves[id];
    if(Math.abs(x+DX*.5-camera)<850)move(x,y,()=>{
      rail(path,P.line,3.3);
      // Parallel etched trace shows the physical bend ahead without obscuring the live route.
      move(0,10,()=>fade(.33,()=>rail(path,P.line,1)));
      const lead=j===i?ramp(b,2.93,3.99):j<i?1:0;
      if(lead>0)rail(path,P.hot,3.1,0,lead);
      if(j===i&&b>2.93&&b<3.999)traveler(path,lead,P.hot);
      ringPort(outlet,0,P.line,P.bg,5);ringPort(DX+inlet,yAt(j+1)-y,P.line,P.bg,5);
      if(id===6&&j===i) {
        const a=position(path,.5);mono('RETURN',a.x,a.y-17,11,P.dim,'center',1.1);
      }
    });
  }
  for(let j=i-1;j<=i+1;j++){
    const x=DX*j;
    if(Math.abs(x-camera)>810)continue;
    const local=beat-j*4;
    const id=mod(j,BARS);
    move(x,yAt(j),()=>{
      if(id===0 && local<.8){
        g.beginPath();g.rect(inlet-2,-170,750,340);g.clip();
      }
      drawStation[id](Math.max(0,Math.min(4,local)),P,time);
      const start=[2.12,2.18,2.65,2.73,2.86,2.84,2.43][id];
      if(local>start&&local<2.99)traveler(exits[id],ramp(local,start,2.99),P.hot,true);
    });
  }
  g.restore();
}
function branches(x,y,col,a,scale=1){
  move(x,y,()=>{
    const bx=[-14,-7,14,21];
    for(let k=-1;k<=1;k+=2){
      const q=pathInfo(cubic([bx[0],0],[bx[1],k*17],[bx[2],k*17],[bx[3],0]));
      rail(q,col,1.4);if(a>0)rail(q,col,2.5,0,a);
    }
  },0,scale);
}
function foot(i,next,u,P,b){
  const j=u<.5?i:next,vis=1-.84*Math.sin(Math.PI*u);
  fade(vis,()=>{
    mono(copy[j][3],54,780,14,P.dim,'left',1.7);
    textRun(copy[j][2],52,824,29,'r',P.fg,'left',-.7);
  });
  const baseY=881,lo=81,span=133,xx=id=>lo+id*span;
  const track=pathInfo([[xx(0),baseY],[xx(6),baseY]]);
  rail(track,P.line,1.5);
  const turn=ramp(b,2.95,3.98);
  const tail=pathInfo(joinPaths(cubic([xx(6),baseY],[xx(6)+42,baseY],[xx(6)+42,baseY+34],[xx(6)+8,baseY+34]),
    [[xx(6)+8,baseY+34],[xx(0)-8,baseY+34]],cubic([xx(0)-8,baseY+34],[xx(0)-42,baseY+34],[xx(0)-42,baseY],[xx(0),baseY])));
  fade(.6,()=>rail(tail,P.line,1.25));
  if(i<6){
    rail(track,P.fg,2.2,0,(i+turn)/6);
  }else {rail(track,P.fg,2.2);if(turn>0){rail(tail,P.fg,2,0,turn);const p=position(tail,turn);dot(p.x,p.y,4.5,P.fg);}}
  for(let s=0;s<BARS;s++){
    const x=xx(s),nodeActive=s===i, on=s<i||nodeActive;
    if(s===4){const ret=pathInfo(cubic([x+25,baseY],[x+26,baseY+23],[x-23,baseY+23],[x-23,baseY]));rail(ret,on?P.fg:P.line,1.5);}
    if(s===5)branches(x,baseY,on?P.fg:P.line,nodeActive?.7:0);
    if(nodeActive){dot(x,baseY,12,P.bg,P.fg,1.6);dot(x,baseY,6,P.fg);}
    else if(s===4)svg('M '+(x-5)+' '+baseY+' l 5 -5 l 5 5 l -5 5 Z',on?P.fg:P.bg,on?P.fg:P.line,1.5);
    else dot(x,baseY,4.3,on?P.fg:P.bg,on?P.fg:P.line,1.55);
  }
  if(i<6&&turn>0){dot(xx(i)+span*turn,baseY,4.6,P.fg);}
}
function drawFrame(seconds){
  const t=mod(seconds,SECONDS),beat=SignalEdit.phaseAtTime(t),i=Math.min(BARS-1,Math.floor(beat/4)),b=beat-i*4,next=(i+1)%BARS;
  const u=between(b,3.24,4),P=pColor(i,next,glide(u));
  g.setTransform(canvas.width/960,0,0,canvas.height/960,0,0);g.lineJoin='round';g.lineCap='round';
  g.fillStyle=P.bg;g.fillRect(0,0,960,960);
  pageHead(P);heading(i,next,u,P);worldGraph(beat,i,b,P,t);foot(i,next,u,P,b);
  g.save();g.globalAlpha=.24;g.fillStyle=grain;g.fillRect(0,0,960,960);g.restore();
}
let clockValue=0;
const clock={get playhead(){return clockValue;},set playhead(value){clockValue=Number(value);drawFrame(clockValue);}};
window.renderAt=seconds=>{
  window.__timelines.main.time(Math.max(0,Math.min(SECONDS,seconds)),false);
};
window.filmReady=Promise.all([
  document.fonts.load('800 88px InterFilm'),document.fonts.load('500 29px InterFilm'),
  document.fonts.load('italic 104px InstrumentFilm'),document.fonts.load('14px MonoFilm')
]).then(()=>{drawFrame(clockValue);return true;});
