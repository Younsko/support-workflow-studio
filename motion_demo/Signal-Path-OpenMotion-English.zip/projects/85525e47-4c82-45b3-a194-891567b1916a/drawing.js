'use strict';
// Vector drawing primitives shared by the seven stations. Coordinates are in a 960-unit square.
const canvas = document.getElementById('route');
const g = canvas.getContext('2d', {alpha:false});
const tau = Math.PI * 2;
const paper = '#f5edd8', ink = '#132c25', mint = '#d4ee92', orange = '#f3a179';
const deep = '#17372e', warm = '#eddcc3';
const clamp = n => Math.max(0,Math.min(1,n));
const mix = (a,b,t) => a+(b-a)*t;
const between = (n,a,b) => clamp((n-a)/(b-a));
const ease = x => x*x*(3-2*x);
const glide = x => x*x*x*(10+x*(6*x-15));
const ramp = (t,a,b) => ease(between(t,a,b));
const mod = (n,m) => (n%m+m)%m;
function spring(t, frequency=7) {
  if(t<=0) return 0;
  const x=t*frequency;
  return 1-Math.exp(-x)*(Math.cos(x*.54)+Math.sin(x*.54)/.54);
}
function color(a,b,k) {
  if(k<=0) return a; if(k>=1) return b;
  const av=parseInt(a.slice(1),16), bv=parseInt(b.slice(1),16);
  return 'rgb('+[16,8,0].map(s=>Math.round(mix((av>>s)&255,(bv>>s)&255,k))).join(',')+')';
}
function withStyle(draw) { g.save(); draw(); g.restore(); }
function move(x,y,draw,rotation=0,scale=1) {
  g.save();g.translate(x,y);if(rotation) g.rotate(rotation);
  if(scale!==1)g.scale(scale,scale);draw();g.restore();
}
function fade(op,draw) {
  if(op<=0) return;
  g.save();g.globalAlpha*=Math.min(op,1);draw();g.restore();
}
function fillPath(p,fill,stroke,w=2) {
  if(fill){g.fillStyle=fill;g.fill(p);}
  if(stroke){g.strokeStyle=stroke;g.lineWidth=w;g.stroke(p);}
}
function svg(s,f,c,w){fillPath(new Path2D(s),f,c,w);}
function rect(x,y,w,h,r,fill,stroke,width=2) {
  const p=new Path2D(); if(r) p.roundRect(x,y,w,h,r);else p.rect(x,y,w,h);
  fillPath(p,fill,stroke,width);
}
function dot(x,y,r,fill,stroke,w=2){
  const p=new Path2D();p.arc(x,y,r,0,tau);fillPath(p,fill,stroke,w);
}
function arc(x,y,r,a,b,c,w) {
  g.beginPath();g.arc(x,y,r,a,b);g.strokeStyle=c;g.lineWidth=w;g.stroke();
}
function line(x1,y1,x2,y2,c,w=2) {
  g.beginPath();g.moveTo(x1,y1);g.lineTo(x2,y2);g.lineWidth=w;g.strokeStyle=c;g.stroke();
}
function textRun(str,x,y,sz,style,c,align='left',track=0) {
  g.save();const font=style==='s'?'italic '+sz+'px InstrumentFilm':style==='m'?sz+'px MonoFilm':(style==='b'?'800 ':'500 ')+sz+'px InterFilm';
  g.font=font;g.textBaseline='alphabetic';g.textAlign=align;g.letterSpacing=track+'px';
  g.fillStyle=c;g.fillText(str,x,y);g.restore();
}
function mono(str,x,y,sz,c,align='left',track=1) {textRun(str,x,y,sz,'m',c,align,track);}
function type(str,x,y,sz,c,align='left',track=-.6) {textRun(str,x,y,sz,'b',c,align,track);}
function italic(str,x,y,sz,c,align='left') {textRun(str,x,y,sz,'s',c,align,-.8);}
function ringPort(x,y,c,fill=ink,r=7) {dot(x,y,r,fill,c,2);dot(x,y,2.4,c);}
function plus(x,y,c,s=5){line(x-s,y,x+s,y,c,1.1);line(x,y-s,x,y+s,c,1.1);}
function check(x,y,s,c,w=3){
  g.beginPath();g.moveTo(x-.54*s,y-.02*s);g.lineTo(x-.15*s,y+.38*s);g.lineTo(x+.57*s,y-.42*s);
  g.strokeStyle=c;g.lineWidth=w;g.stroke();
}
function arrow(x,y,s,c,dir=1) {
  line(x-s*dir,y,x+s*dir,y,c,2.6);line(x+s*dir,y,x+s*.23*dir,y-s*.76,c,2.6);line(x+s*dir,y,x+s*.23*dir,y+s*.76,c,2.6);
}
function cubic(a,b,c,d,n=32) {
  const pts=[];
  for(let i=0;i<=n;i++){const t=i/n,u=1-t;
    pts.push([u*u*u*a[0]+3*u*u*t*b[0]+3*u*t*t*c[0]+t*t*t*d[0],
      u*u*u*a[1]+3*u*u*t*b[1]+3*u*t*t*c[1]+t*t*t*d[1]]);}
  return pts;
}
function joinPaths(...parts){return parts.flatMap((p,i)=>i?p.slice(1):p);}
function pathInfo(pts){
  let length=0;const distances=[0];
  for(let i=1;i<pts.length;i++){length+=Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]);distances.push(length);}
  return {pts,distances,length};
}
function position(path,t) {
  const {pts,distances,length}=path; const target=clamp(t)*length;
  let i=1;while(i<distances.length-1 && distances[i]<target)i++;
  const ratio=(target-distances[i-1])/(distances[i]-distances[i-1]||1);
  return {x:mix(pts[i-1][0],pts[i][0],ratio),y:mix(pts[i-1][1],pts[i][1],ratio),i};
}
function rail(path,c,w=3,from=0,to=1) {
  if(to<=from) return;const a=position(path,from),b=position(path,to);
  g.beginPath();g.moveTo(a.x,a.y);
  for(let i=a.i;i<b.i;i++)g.lineTo(...path.pts[i]);g.lineTo(b.x,b.y);
  g.strokeStyle=c;g.lineWidth=w;g.stroke();
}
function traveler(path,v,accent,small=false) {
  const p=position(path,v);rail(path,accent,small?5:8,Math.max(0,v-(small?.16:.22)),v);
  dot(p.x,p.y,small?5.5:9,accent,ink,small?1.3:2);
  if(!small)dot(p.x,p.y,3,ink);
}
function route(a,b) {
  const mid=(a[0]+b[0])/2;
  return pathInfo(cubic(a,[mid,a[1]],[mid,b[1]],b));
}
function dashed(fn,d=[4,6]){g.save();g.setLineDash(d);fn();g.restore();}
function makeTile(w,h,draw){
  const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);return c;
}
const paperTile=makeTile(128,128,(c,w,h)=>{
  let seed=343;function random(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
  for(let i=0;i<1770;i++){const x=random()*w,y=random()*h,v=random();
    c.fillStyle=v>.5?'rgba(255,250,219,.17)':'rgba(7,24,18,.16)';c.fillRect(x,y,.65+random()*.7,.65+random()*.7);}
});
const grain=g.createPattern(paperTile,'repeat');
const engraving=makeTile(104,184,(c,w,h)=>{
  c.strokeStyle=ink;c.lineWidth=1.05;
  for(let i=-18;i<24;i++){c.beginPath();for(let y=-2;y<h+2;y+=2){const x=i*7+14*Math.sin(y/184*tau*2+i*.26)+3*Math.sin(y/184*tau*5);if(y===-2)c.moveTo(x,y);else c.lineTo(x,y);}c.stroke();}
});
const openMotionStrip=OpenMotionReconstruction.createTextureLayer({image:engraving,box:[-207,-79,74,158],velocity:[104/14,0],wrapX:true,wrapY:true,resolution:1.5});
