# Signal Path

Fourteen-second motion design for Support Workflow Studio. Case SUP-4821, guide KB-104, and the notes depict a fictional VPN support request.

## Picture and sound edit

| Step | Film time | Visual beat |
| --- | --- | --- |
| Ticket intake | 0.00–1.27 s | The VPN ticket enters the workflow. |
| Trigger | 1.27–2.55 s | The Jira trigger activates the workflow relay. |
| Triage | 2.55–3.82 s | The request is normalized and routed to the N2 lane. |
| Knowledge | 3.82–6.37 s | Approved guidance is attached to the ticket. |
| Revision | 6.37–8.92 s | At 8.6/10 the plan loops back; at 9.2/10 it passes the quality gate. |
| Verification | 8.92–11.45 s | Three specialist reviews check the draft independently. |
| Human decision | 11.45–14.00 s | The reviewer approves the response before the separate Jira publication step. |

The film uses a fourteen-second edit of the user-provided SABI track. Its measured pulse is 95 BPM; 22 beats are mapped to the 14-second timeline while preserving the original pitch. The sound edit loops to the opening beat.

## Edit the composition

In OpenMotion Studio, open **All projects**, select **Import projects**, and choose the OpenMotion project archive. The **Signal Path** composition has separate picture, music, and effects tracks.

The camera and on-screen copy are in `film.js`; the node illustrations are in `stations.js`. `edit-grid.js` maps musical accents, visible actions, and sound cues to frames. `foley.mjs` generates the interface sound-effects track with `node foley.mjs`. The locally supplied music edit is kept outside the public source bundle.
