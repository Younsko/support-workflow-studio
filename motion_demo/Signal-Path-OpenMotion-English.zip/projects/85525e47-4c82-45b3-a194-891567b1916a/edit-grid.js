'use strict';
// Each row is [beat in the song edit, phase in the animation, optional sound].
// Phase 0..4 is intake, 4..8 the trigger, and so on. Every contact is on a picture frame.
(() => {
  const fps=60, duration=14, beats=22;
  const marks=[
    [0,0], [.25,.42,'paper-in'], [.75,1.55], [1.5,2.98], [1.75,3.50,'travel-1'], [2,4],
    [2.16,4.37], [2.5,4.842,'relay'], [3.5,6.98], [3.75,7.50,'travel-2'], [4,8],
    [4.5,8.68], [5,9.182,'selector'], [5.5,10.98], [5.75,11.50,'travel-3'], [6,12],
    [6.5,12.64,'leaf'], [7.5,13.79,'clip'], [8.5,14.70], [9,14.98],
    [9.5,15.50,'travel-4'], [10,16],
    [11,16.831,'revise'], [11.25,17.00], [11.75,17.61,'backtrack'], [12,18.00],
    [13,18.861,'pass'], [13.18,18.98], [13.5,19.50,'travel-5'], [14,20],
    [14.75,21.051,'review-a'], [15,21.241,'review-b'], [15.25,21.431,'review-c'],
    [16.5,22.621,'verified'], [17,22.98], [17.5,23.50,'travel-6'], [18,24],
    [19,24.881,'approve'], [19.5,25.48], [20.5,26.221,'publish'], [21,26.98],
    [21.5,27.50,'return'], [22,28]
  ].map(([beat,phase,sound])=>({beat,phase,sound,frame:Math.round(beat*fps*duration/beats)}));

  const gaps=marks.slice(1).map((b,i)=>b.frame-marks[i].frame);
  const slopes=gaps.map((gap,i)=>(marks[i+1].phase-marks[i].phase)/gap);
  // A monotone Hermite interpolation eases camera speed across unequal scene lengths
  // while keeping the visible material contact exactly on its mapped frame.
  const velocity=marks.map((_,i)=>{
    if(i===0)return slopes[0];
    if(i===marks.length-1)return slopes.at(-1);
    const a=2*gaps[i]+gaps[i-1], b=gaps[i]+2*gaps[i-1];
    return (a+b)/(a/slopes[i-1]+b/slopes[i]);
  });
  function phaseAtTime(time) {
    const frame=Math.max(0,Math.min(duration*fps,time*fps));
    let i=0;
    while(i<marks.length-2 && frame>marks[i+1].frame)i++;
    const a=marks[i], b=marks[i+1], span=gaps[i], t=(frame-a.frame)/span;
    const u=t*t, v=u*t;
    return (2*v-3*u+1)*a.phase+(v-2*u+t)*span*velocity[i]+
           (-2*v+3*u)*b.phase+(v-u)*span*velocity[i+1];
  }
  globalThis.SignalEdit=Object.freeze({fps,duration,beats,sourceBPM:95,marks,phaseAtTime});
})();
